# SilliqlaParketbot

Ready to deploy Telegram bot.
